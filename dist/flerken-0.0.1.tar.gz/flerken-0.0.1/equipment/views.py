# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.views.generic import TemplateView
from equipment.models import Device
from utils.base import PublicView
from django.shortcuts import render

# Create your views here.
#  class LihuiPage(TemplateView):
class LihuiPage(PublicView):
    template_name = 'index.html'
