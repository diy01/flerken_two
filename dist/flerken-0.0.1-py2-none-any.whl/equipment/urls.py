#coding=utf-8
from django.conf.urls import url
from django.contrib import admin
from equipment import views
from django.urls import path

urlpatterns = [

    path('', views.LihuiPage.as_view()),


    ]