from django.apps import AppConfig


class LicenseConfig(AppConfig):
    name = 'license'
